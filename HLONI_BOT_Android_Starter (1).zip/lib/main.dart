import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() => runApp(const HloniBotApp());

class HloniBotApp extends StatelessWidget {
  const HloniBotApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HLONI BOT',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF45D6A4),
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: const Color(0xFF0B1018),
        useMaterial3: true,
      ),
      home: const DashboardPage(),
    );
  }
}

class BotStatus {
  final bool connected;
  final bool tradingEnabled;
  final String accountLabel;
  final String balance;
  final String equity;
  final String todayPnl;
  final int openPositions;
  final String message;

  const BotStatus({
    required this.connected,
    required this.tradingEnabled,
    required this.accountLabel,
    required this.balance,
    required this.equity,
    required this.todayPnl,
    required this.openPositions,
    required this.message,
  });

  factory BotStatus.fromJson(Map<String, dynamic> json) => BotStatus(
    connected: json['connected'] == true,
    tradingEnabled: json['trading_enabled'] == true,
    accountLabel: (json['account_label'] ?? 'Account not supplied').toString(),
    balance: (json['balance'] ?? '—').toString(),
    equity: (json['equity'] ?? '—').toString(),
    todayPnl: (json['today_pnl'] ?? '—').toString(),
    openPositions: (json['open_positions'] is int) ? json['open_positions'] as int : 0,
    message: (json['message'] ?? 'No server response').toString(),
  );

  static const disconnected = BotStatus(
    connected: false,
    tradingEnabled: false,
    accountLabel: 'Not connected',
    balance: '—',
    equity: '—',
    todayPnl: '—',
    openPositions: 0,
    message: 'Connect a secure MT5 bridge to see live account information.',
  );
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  // Configure these only after you have a secured backend API.
  // Never place your broker password or MT5 master password in this app.
  static const String apiBaseUrl = String.fromEnvironment('HLONI_API_URL', defaultValue: '');
  static const String apiToken = String.fromEnvironment('HLONI_API_TOKEN', defaultValue: '');

  BotStatus status = BotStatus.disconnected;
  bool loading = false;
  String connectionNote = 'Not connected to a trading server';

  Future<void> refreshStatus() async {
    if (apiBaseUrl.isEmpty || apiToken.isEmpty) {
      setState(() => connectionNote =
          'No API configured. The app is a starter interface and is not connected to a broker.');
      return;
    }
    setState(() => loading = true);
    try {
      final uri = Uri.parse('$apiBaseUrl/status');
      final response = await http.get(uri, headers: {
        'Authorization': 'Bearer $apiToken',
        'Accept': 'application/json',
      }).timeout(const Duration(seconds: 10));
      if (response.statusCode != 200) {
        throw Exception('Server returned HTTP ${response.statusCode}');
      }
      final decoded = jsonDecode(response.body) as Map<String, dynamic>;
      setState(() {
        status = BotStatus.fromJson(decoded);
        connectionNote = status.message;
      });
    } catch (e) {
      setState(() {
        status = BotStatus.disconnected;
        connectionNote = 'Could not reach the configured server. Check the API setup.';
      });
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> showControlNotice(String action) async {
    // Intentionally no live-trading control is wired up in this starter.
    // Add authenticated server-side controls only after safeguards are implemented.
    if (!mounted) return;
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Control not connected'),
        content: Text(
          '"$action" is not connected to MT5 yet. A secure server-side endpoint, '
          'authorization checks, and confirmation safeguards must be implemented first.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final connected = status.connected;
    return Scaffold(
      appBar: AppBar(
        title: const Row(
          children: [
            Icon(Icons.show_chart, color: Color(0xFF45D6A4)),
            SizedBox(width: 10),
            Text('HLONI BOT', style: TextStyle(fontWeight: FontWeight.w800)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            onPressed: loading ? null : refreshStatus,
            icon: loading
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.refresh),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: refreshStatus,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF17352F), Color(0xFF151E2A)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0xFF2A5148)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('BOT CONNECTION', style: TextStyle(color: Colors.white70, letterSpacing: 1.2)),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Icon(Icons.circle, size: 12, color: connected ? const Color(0xFF45D6A4) : Colors.orangeAccent),
                      const SizedBox(width: 8),
                      Text(connected ? 'Connected' : 'Not connected',
                          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(connectionNote, style: const TextStyle(color: Colors.white70)),
                ],
              ),
            ),
            const SizedBox(height: 18),
            const Text('ACCOUNT OVERVIEW', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.1)),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(child: _MetricCard(label: 'Balance', value: status.balance, icon: Icons.account_balance_wallet_outlined)),
                const SizedBox(width: 10),
                Expanded(child: _MetricCard(label: 'Equity', value: status.equity, icon: Icons.pie_chart_outline)),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(child: _MetricCard(label: "Today's P/L", value: status.todayPnl, icon: Icons.trending_up)),
                const SizedBox(width: 10),
                Expanded(child: _MetricCard(label: 'Open positions', value: '${status.openPositions}', icon: Icons.swap_vert)),
              ],
            ),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF131B27),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFF273242)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('TRADING CONTROLS', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.1)),
                  const SizedBox(height: 8),
                  const Text('Controls are intentionally disabled until the secure MT5 bridge is configured.',
                      style: TextStyle(color: Colors.white70)),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => showControlNotice('Pause new trades'),
                          icon: const Icon(Icons.pause_circle_outline),
                          label: const Text('Pause bot'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: () => showControlNotice('Resume new trades'),
                          icon: const Icon(Icons.play_arrow),
                          label: const Text('Resume bot'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.shield_outlined, color: Color(0xFF45D6A4)),
              title: const Text('Security reminder'),
              subtitle: const Text('Never enter your broker password in this app. Use an authenticated HTTPS API and protect its token.'),
            ),
            const SizedBox(height: 12),
            Text('Account: ${status.accountLabel}', style: const TextStyle(color: Colors.white54)),
            const SizedBox(height: 24),
            const Text(
              'Starter version — not connected to live trading. Do not use this screen as proof that a bot is running.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.orangeAccent, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}

class _MetricCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;

  const _MetricCard({required this.label, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(
      color: const Color(0xFF131B27),
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: const Color(0xFF273242)),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: const Color(0xFF45D6A4)),
        const SizedBox(height: 12),
        Text(value, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        Text(label, style: const TextStyle(color: Colors.white60)),
      ],
    ),
  );
}
