# HLONI BOT Android Starter

This is the **Flutter source project** for an Android companion dashboard. It is not an APK yet and is not connected to a broker or live MT5 account.

## What is included
- Android-friendly dashboard UI
- Status, balance, equity, daily P/L, and open-position cards
- Optional authenticated HTTPS `GET /status` request
- Placeholder controls that intentionally do not send trading commands
- No broker password stored in the app

## Important limitation
The existing MQL5 Expert Advisor normally runs in desktop MetaTrader 5 on a Windows computer or compatible hosted environment. The Android MT5 app does not run custom MQL5 Expert Advisors directly. This mobile app is only the interface; a separate MT5 bridge/backend is required for real account data and controls.

## Requirements to build an APK
- Flutter SDK
- Android SDK / Android build tools
- A computer or a cloud build service that supports Flutter Android builds

The source can be edited from a phone using a browser-based IDE, but compiling an APK may require a supported cloud build service or a computer. Free service limits can change.

## Run/build on a Flutter-enabled environment
1. Extract this ZIP.
2. Run `flutter pub get`.
3. Run `flutter run` to test the interface.
4. To build an APK: `flutter build apk --release`.

## Configure status API
When a secure HTTPS backend exists, build with:
`flutter build apk --release --dart-define=HLONI_API_URL=https://your-api.example --dart-define=HLONI_API_TOKEN=YOUR_SHORT_LIVED_TOKEN`

Do not commit real tokens to source control or share them in chat. Prefer short-lived tokens and a server-side authentication system rather than a permanent secret embedded in a distributed app; values passed with `--dart-define` can be extracted from an APK.

The backend `/status` endpoint should return JSON such as:
```json
{
  "connected": true,
  "trading_enabled": false,
  "account_label": "Live account",
  "balance": "—",
  "equity": "—",
  "today_pnl": "—",
  "open_positions": 0,
  "message": "Connected to MT5 bridge"
}
```
Only return real account data after authenticating and verifying the MT5 bridge. Never fabricate account data.

## Before enabling real trading controls
Implement server-side authorization, HTTPS, audit logs, explicit confirmations, risk limits, duplicate-command protection, and a reliable way to stop new entries. Test carefully and understand that live trading can lose money.
